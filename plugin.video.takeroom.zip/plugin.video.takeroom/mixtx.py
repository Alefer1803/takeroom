# -*- coding: utf-8 -*-
import sys
import xbmcplugin
import xbmcgui
import xbmc
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import os
import time

# --- CONFIGURAÇÕES ---
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])
CACHE_FILE = xbmc.translatePath("special://profile/addon_data/plugin.video.takeroom/cache_menu.xml")
CACHE_TIME = 300  # 5 minutos

# URL principal do menu remoto
URL_MENU = "https://raw.githubusercontent.com/Alefer1803/takeroom/refs/heads/main/menuprincipal"


# --- FUNÇÕES AUXILIARES ---

def log(msg):
    xbmc.log(f"[TakeRoom] {msg}", xbmc.LOGINFO)


def fetch_url(url):
    """Busca um arquivo remoto com cache básico."""
    try:
        if os.path.exists(CACHE_FILE):
            mod_time = os.path.getmtime(CACHE_FILE)
            if time.time() - mod_time < CACHE_TIME:
                with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                    log("Usando cache local do menu.")
                    return f.read()

        log(f"Baixando XML remoto: {url}")
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read().decode('utf-8')

        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            f.write(data)

        return data
    except Exception as e:
        xbmcgui.Dialog().notification("Erro de conexão", str(e), xbmcgui.NOTIFICATION_ERROR)
        log(f"Erro ao buscar URL: {e}")
        return None


def parse_xml(xml_text):
    """Faz parse do XML remoto em uma estrutura de lista."""
    try:
        root = ET.fromstring(xml_text)
        if root.tag.lower() not in ["menu", "channels"]:
            for child in root:
                if child.tag.lower() in ["menu", "channels"]:
                    root = child
                    break
        return root.findall("item") or root.findall("channel")
    except Exception as e:
        xbmcgui.Dialog().notification("Erro XML", str(e), xbmcgui.NOTIFICATION_ERROR)
        log(f"Erro ao parsear XML: {e}")
        return []


def add_dir(name, link, thumb="", fanart="", info=""):
    """Adiciona um item de diretório no Kodi."""
    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
    list_item.setInfo('video', {'title': name, 'plot': info})

    if link.lower().endswith(".xml"):
        url = f"{BASE_URL}?action=listar&url={urllib.parse.quote(link)}"
        is_folder = True
    else:
        url = link
        list_item.setProperty('IsPlayable', 'true')
        is_folder = False

    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, is_folder)


def listar_menu(url):
    """Lista os itens do menu principal."""
    xml_text = fetch_url(url)
    if not xml_text:
        return

    items = parse_xml(xml_text)
    if not items:
        xbmcgui.Dialog().notification("Erro", "Nenhum item encontrado", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Take Room")
    xbmcplugin.setContent(ADDON_HANDLE, "videos")

    for item in items:
        name = item.findtext("name", "Sem nome")
        link = item.findtext("link") or item.findtext("externallink") or ""
        thumb = item.findtext("thumbnail", "")
        fanart = item.findtext("fanart", "")
        info = item.findtext("info", "")

        add_dir(name, link, thumb, fanart, info)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router(paramstring):
    """Gerencia as ações do plugin."""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "listar":
        listar_menu(params.get("url"))
    else:
        listar_menu(URL_MENU)


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
