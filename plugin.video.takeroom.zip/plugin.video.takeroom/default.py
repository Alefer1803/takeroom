import sys
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import xbmcplugin
import xbmcgui

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])

# URL do menu principal remoto
URL_MENU = "https://raw.githubusercontent.com/Alefer1803/takeroom/refs/heads/main/menuprincipal"

def listar_menu(url):
    try:
        response = urllib.request.urlopen(url)
        data = response.read()
        # remove BOM se existir
        if data.startswith(b'\xef\xbb\xbf'):
            data = data[3:]
        xml_str = data.decode('utf-8')

        root = ET.fromstring(xml_str)

        for item in root.findall('item'):
            name = item.findtext('name', 'Sem nome')
            link = item.findtext('link', '')
            thumb = item.findtext('thumbnail', '')

            list_item = xbmcgui.ListItem(label=name)
            list_item.setArt({'thumb': thumb, 'icon': thumb})

            if link.endswith('.xml'):
                url_final = f"{BASE_URL}?action=listar&url={urllib.parse.quote(link)}"
                is_folder = True
            else:
                url_final = link
                is_folder = False

            xbmcplugin.addDirectoryItem(HANDLE, url_final, list_item, isFolder=is_folder)

        xbmcplugin.endOfDirectory(HANDLE)

    except Exception as e:
        xbmcgui.Dialog().notification("Erro", str(e), xbmcgui.NOTIFICATION_ERROR)

if __name__ == "__main__":
    action = ARGS.get('action', None)
    if action is None:
        listar_menu(URL_MENU)
    elif action[0] == 'listar':
        url = ARGS.get('url', [URL_MENU])[0]
        listar_menu(url)
